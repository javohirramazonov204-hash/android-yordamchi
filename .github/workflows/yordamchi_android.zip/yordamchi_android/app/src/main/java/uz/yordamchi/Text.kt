package uz.yordamchi

import java.util.Calendar

/** O'zbekcha matnni tozalash, son so'zlarini raqamga aylantirish, vaqtni ajratish. */
object Text {
    fun norm(s: String): String {
        var t = s.lowercase()
        for (c in "ʻʼ’‘`´′") t = t.replace(c, '\'')
        t = t.replace(Regex("[^\\p{L}\\p{N}:.' ]"), " ")
        t = t.replace(Regex("\\s+"), " ").trim().trim('.')
        return t
    }

    fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private val units = mapOf(
        "nol" to 0, "bir" to 1, "ikki" to 2, "uch" to 3, "to'rt" to 4,
        "besh" to 5, "olti" to 6, "yetti" to 7, "sakkiz" to 8, "to'qqiz" to 9
    )
    private val tens = mapOf(
        "o'n" to 10, "yigirma" to 20, "o'ttiz" to 30, "qirq" to 40, "ellik" to 50,
        "oltmish" to 60, "yetmish" to 70, "sakson" to 80, "to'qson" to 90
    )
    private val sufs = listOf("dan", "da", "ta", "ga", "ni")

    private fun word(x: String): Pair<Int, String>? {
        units[x]?.let { return Pair(it, "") }
        tens[x]?.let { return Pair(it, "") }
        for (s in sufs) {
            if (x.endsWith(s) && x.length > s.length) {
                val st = x.dropLast(s.length)
                if (st == "bir") continue
                val v = units[st] ?: tens[st]
                if (v != null) return Pair(v, s)
            }
        }
        return null
    }

    /** "o'n besh" -> "15", "soat beshda" -> "soat 5 da" */
    fun numberWords(t: String): String {
        val w = t.split(" ")
        val out = ArrayList<String>()
        var i = 0
        while (i < w.size) {
            val a = word(w[i])
            if (a == null) {
                out.add(w[i]); i++; continue
            }
            var v = a.first
            var suf = a.second
            if (v >= 10 && suf.isEmpty() && i + 1 < w.size) {
                val b = word(w[i + 1])
                if (b != null && b.first in 1..9) {
                    v += b.first; suf = b.second; i++
                }
            }
            out.add(v.toString())
            if (suf.isNotEmpty()) out.add(suf)
            i++
        }
        return out.joinToString(" ")
    }

    data class When(val time: Long, val daily: Boolean, val rest: String)

    fun cleanRest(s: String): String {
        val r = Regex(
            "\\b(eslatib\\s+qo'y\\w*|eslat\\w*|eslab\\s+qol\\w*|deb|iltimos|menga|ertaga|indinga|bugun|" +
                "kechqurun|kechasi|ertalab|kunduzi|har\\s*kuni|kunda|da|dan|soat)\\b"
        ).replace(s, " ")
        return r.replace(Regex("\\s+"), " ").trim(' ', ':', '.', ',')
    }

    /** Matn ichidan vaqtni topadi (raqamlar allaqachon raqam ko'rinishida bo'lishi kerak). */
    fun parseWhen(s0: String, now: Long = System.currentTimeMillis()): When? {
        var s = s0.replace("yarim soat", "30 daqiqa")
        val daily = Regex("\\bhar\\s*kuni\\b|\\bkunda\\b").containsMatchIn(s)

        if (Regex("\\bkeyin\\b").containsMatchIn(s)) {
            var total = 0L
            var found = false
            s = Regex("(\\d+)\\s*(soat|daqiqa|minut|sekund)\\w*").replace(s) { m ->
                found = true
                val n = m.groupValues[1].toLong()
                total += when (m.groupValues[2]) {
                    "soat" -> n * 3600000L
                    "sekund" -> n * 1000L
                    else -> n * 60000L
                }
                " "
            }
            if (found && total > 0) {
                return When(now + total, daily, cleanRest(s.replace(Regex("\\bkeyin\\b"), " ")))
            }
        }

        val pats = listOf(
            Regex("\\b(\\d{1,2})[:.](\\d{2})\\b(?:\\s*da\\b)?"),
            Regex("\\bsoat\\s+(\\d{1,2})(?:\\s+(\\d{2}))?\\b(?:\\s*da\\b)?"),
            Regex("\\b(\\d{1,2})(?:\\s+(\\d{2}))?\\s*da\\b")
        )
        for (p in pats) {
            val m = p.find(s) ?: continue
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            if (h > 23 || mi > 59) continue
            val rest = s.removeRange(m.range)
            if (Regex("\\bkech(qurun|asi)?\\b").containsMatchIn(s) && h < 12) h += 12
            val cal = Calendar.getInstance()
            cal.timeInMillis = now
            cal.set(Calendar.HOUR_OF_DAY, h)
            cal.set(Calendar.MINUTE, mi)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (Regex("\\bindin\\w*").containsMatchIn(s)) cal.add(Calendar.DAY_OF_YEAR, 2)
            else if (Regex("\\bertaga\\b").containsMatchIn(s)) cal.add(Calendar.DAY_OF_YEAR, 1)
            else if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            return When(cal.timeInMillis, daily, cleanRest(rest))
        }
        return null
    }
}

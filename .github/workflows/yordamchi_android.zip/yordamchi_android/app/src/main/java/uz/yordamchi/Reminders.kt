package uz.yordamchi

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class Item(val id: Int, val text: String, val time: Long, val daily: Boolean)

/** Eslatmalar va qaydlar xotirasi (telefon ichida, SharedPreferences). time = 0 bo'lsa oddiy qayd. */
object Store {
    private const val KEY = "items"

    fun all(ctx: Context): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val a = JSONArray(Prefs.sp(ctx).getString(KEY, "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Item(o.getInt("id"), o.getString("text"), o.getLong("time"), o.optBoolean("daily")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, l: List<Item>) {
        val a = JSONArray()
        for (x in l) {
            a.put(JSONObject().put("id", x.id).put("text", x.text).put("time", x.time).put("daily", x.daily))
        }
        Prefs.sp(ctx).edit().putString(KEY, a.toString()).apply()
    }

    fun add(ctx: Context, text: String, time: Long, daily: Boolean): Item {
        val item = Item(Prefs.nextId(ctx), text, time, daily)
        val l = all(ctx)
        l.add(item)
        save(ctx, l)
        return item
    }

    fun update(ctx: Context, item: Item) {
        val l = all(ctx)
        val i = l.indexOfFirst { it.id == item.id }
        if (i >= 0) {
            l[i] = item
            save(ctx, l)
        }
    }

    fun remove(ctx: Context, id: Int) {
        save(ctx, all(ctx).filter { it.id != id })
    }
}

object Scheduler {
    private fun pending(ctx: Context, item: Item): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .setAction("uz.yordamchi.REMIND")
            .putExtra("id", item.id)
            .putExtra("text", item.text)
        return PendingIntent.getBroadcast(ctx, item.id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** true = aniq vaqtda, false = taxminiy (aniq signal ruxsati yo'q). */
    fun schedule(ctx: Context, item: Item): Boolean {
        if (item.time <= 0) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        return try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.time, pending(ctx, item))
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.time, pending(ctx, item))
            exact
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.time, pending(ctx, item))
            false
        }
    }

    fun cancel(ctx: Context, item: Item) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, item))
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        for (x in Store.all(ctx)) {
            if (x.time <= 0) continue
            var item = x
            if (x.time <= now && x.daily) {
                var t = x.time
                while (t <= now) t += 86400000L
                item = x.copy(time = t)
                Store.update(ctx, item)
            }
            if (item.time > now) schedule(ctx, item)
        }
    }
}

object Notifier {
    private const val CH = "reminders_v1"

    private fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Eslatmalar", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
            nm.createNotificationChannel(ch)
        }
    }

    fun show(ctx: Context, id: Int, text: String) {
        ensure(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("⏰ Eslatma")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(100000 + id, n)
        } catch (_: Exception) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val text = intent.getStringExtra("text") ?: "Eslatma"
        Notifier.show(ctx, id, text)
        val item = Store.all(ctx).firstOrNull { it.id == id }
        if (item != null && item.daily) {
            var t = item.time
            val now = System.currentTimeMillis()
            while (t <= now) t += 86400000L
            val next = item.copy(time = t)
            Store.update(ctx, next)
            Scheduler.schedule(ctx, next)
        }
        AssistantService.instance?.say("⏰ $text")
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.rescheduleAll(ctx)
    }
}

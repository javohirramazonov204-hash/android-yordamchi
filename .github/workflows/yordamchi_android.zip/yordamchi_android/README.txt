YORDAMCHI (Android) - o'rnatish qadamlari
==========================================

A) Tayyorgarlik (bir marta)
1. Android Studio'ni yuklab o'rnating: https://developer.android.com/studio (Next-Next, hammasini standart qoldiring).
2. Ovoz modeli: https://alphacephei.com/vosk/models dan "vosk-model-small-uz-0.22" ni yuklab oching (zip).
   Ichidan chiqqan papkani "model-uz" deb nomlang va shu yerga qo'ying:
       yordamchi_android/app/src/main/assets/model-uz/     (ichida am, graph, conf, ivector papkalari)
   (Model bo'lmasa ham ilova ishlaydi: bosib gapirsangiz Google tanigichidan foydalanadi, internet kerak.
    "Doim tinglash" faqat model bilan ishlaydi.)
3. Telefonda: Sozlamalar - Telefon haqida - "Yig'ma raqam" (Build number) ga 7 marta bosing.
   Keyin Sozlamalar - Dasturchilar uchun - "USB orqali nosozliklarni tuzatish" ni yoqing.

B) Ishga tushirish
1. Android Studio - Open - yordamchi_android papkasini tanlang. Birinchi marta yuklashlar bo'ladi (internet kerak, 5-15 daqiqa).
2. Telefonni USB bilan ulang, telefonda "Ruxsat berish" ni bosing.
3. Yuqoridagi yashil "Run" (uchburchak) tugmasini bosing. Ilova telefonga o'rnatiladi.

C) Birinchi ishga tushirish: ruxsatlar
Ilova ichidagi ro'yxatdagi har bir "Yoqish" tugmasini bosing:
- Boshqa ilovalar ustida ko'rsatish  -> emoji uchun
- Maxsus imkoniyatlar (Accessibility) -> qulflash, ortga, bosh ekran, skrinshot uchun
  Agar yoqib bo'lmasa (kulrang): Ilova sahifasi - yuqoridagi uch nuqta - "Cheklangan sozlamalarga ruxsat berish", so'ng qayta urining.
- Mikrofon, Bildirishnomalar, Aniq vaqtli signal, Batareya cheklovisiz ishlash.

D) Ishlatish
- Emoji ekran o'ng chetida yarim ko'rinib turadi. Bosing - chiqib keladi va eshitadi. Buyruqni ayting.
- Emojini tepa-pastga sudrab joyini o'zgartirish mumkin. Uzoq bosilsa ilova sozlamalari ochiladi.
- Ilova ichida emojini tanlang, buyruqni yozib sinab ko'ring.
- Telefon qayta yoqilgach ilovani bir marta oching (Android mikrofonli xizmatni o'zi ishga tushirishga ruxsat bermaydi).
  Eslatmalar esa qayta yoqilgandan keyin ham o'zi ishlayveradi.

E) Buyruqlar
1) "15:30 da dori ich deb eslat" / "30 daqiqadan keyin choy qo'y deb eslat" / "ertaga 8:00 da ... deb eslat" / "har kuni 9:00 da ..."
2) "eslab qol: ..." ; "eslatmalarim" ; "eslatma 2 ni o'chir" ; "barcha eslatmalarni o'chir"
3) "ekranni qulfla"
4) "chiroqni yoq" / "chiroqni o'chir"
5) "<ilova> och"  (masalan "telegram och", "kamera och")
6) "ilovadan chiq"  (bosh ekranga chiqadi; boshqa ilovani Android "o'ldirishga" ruxsat bermaydi)
7) "ortga qayt"
8) "keshni tozala" (o'z keshi) / "telegram keshini tozala" (ilova sahifasi ochiladi, "Keshni tozalash"ni o'zingiz bosasiz)
9) "skrinshot qil"
10) O'rgatish: "pabji = pubg" (keyin "pabji och" PUBG ni ochadi); "qulflab qo'y = ekranni qulfla"; "taxalluslarim"; "pabji ni unut"
    Oldindan tayyor: galareya/galireya/rasmlar (galereya), claud/klod (Claude), qaydlar (qaydlar ilovasi), instagram.
Chaqiruv so'zlari (doim tinglash): Hoy Yordamchi / Hamroh / Madadkor.

F) Muammo bo'lsa
- Gradle xatosi chiqsa: xato matnini menga yuboring.
- "Ilova ochilmadi": ilova nomi telefonda boshqacha yozilgan bo'lishi mumkin; Commands.kt dagi ALIAS ro'yxatiga qo'shamiz.
- Skrinshot/qulflash ishlamasa: Maxsus imkoniyatlarda "Yordamchi" yoqilganini tekshiring.
- Eslatma kech chalinsa: "Aniq vaqtli signal" va "Batareya cheklovisiz" ruxsatlarini bering.

Eslatma: bu ilova faqat shaxsiy foydalanish uchun (Play Market'ga qo'yilmaydi).

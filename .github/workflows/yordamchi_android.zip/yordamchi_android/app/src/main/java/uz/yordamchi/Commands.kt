package uz.yordamchi

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Buyruqlarni tahlil qilib bajaradi. Asosiy oqimda (main thread) chaqiring. */
class Commands(context: Context) {
    private val ctx: Context = context.applicationContext
    private val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

    data class Reply(val text: String, val ok: Boolean = true)
    data class AppInfo(val label: String, val norm: String, val pkg: String)

    companion object {
        @Volatile
        var torchOn = false

        private var appCache: List<AppInfo> = emptyList()
        private var appCacheAt = 0L

        // O'zbekcha nom -> ilova nomida uchraydigan so'z
        private val ALIAS = mapOf(
            "galareya" to listOf("gallery", "photos", "galereya", "rasmlar"),
            "galireya" to listOf("gallery", "photos", "galereya", "rasmlar"),
            "rasmlar" to listOf("gallery", "photos", "galereya", "rasmlar"),
            "claud" to listOf("claude"),
            "klod" to listOf("claude"),
            "klaud" to listOf("claude"),
            "claude" to listOf("claude"),
            "qaydlar" to listOf("notes", "keep", "qaydlar", "eslatmalar"),
            "kamera" to listOf("camera", "kamera"),
            "sozlamalar" to listOf("settings", "sozlamalar"),
            "sozlama" to listOf("settings", "sozlamalar"),
            "xarita" to listOf("maps", "xarita"),
            "telefon" to listOf("phone", "telefon", "dialer"),
            "kontaktlar" to listOf("contacts", "kontaktlar"),
            "galereya" to listOf("gallery", "photos", "galereya", "rasmlar"),
            "hisoblagich" to listOf("calculator", "kalkulyator", "hisoblagich"),
            "kalkulyator" to listOf("calculator", "kalkulyator"),
            "soat" to listOf("clock", "soat"),
            "pochta" to listOf("gmail", "mail", "pochta"),
            "brauzer" to listOf("chrome", "browser", "brauzer"),
            "xabarlar" to listOf("messages", "xabarlar", "sms"),
            "yutub" to listOf("youtube"),
            "telegram" to listOf("telegram"),
            "vatsap" to listOf("whatsapp"),
            "instagram" to listOf("instagram")
        )

        val HELP = """Buyruqlar:
1) Eslatma: "15:30 da dori ich deb eslat", "30 daqiqadan keyin choy qo'y deb eslat", "ertaga 8:00 da ... deb eslat", "har kuni 9:00 da ... deb eslat"
2) Qayd: "eslab qol: parol daftarda"
3) "eslatmalarim" - ro'yxat; "eslatma 2 ni o'chir"; "barcha eslatmalarni o'chir"
4) "ekranni qulfla"
5) "chiroqni yoq" / "chiroqni o'chir"
6) "<ilova nomi> och" (masalan: "telegram och")
7) "ilovadan chiq" (bosh ekranga chiqadi)
8) "ortga qayt"
9) "keshni tozala" / "telegram keshini tozala"
10) skrinshot qil
11) O'rgatish: "pabji = pubg" (keyin "pabji och" PUBG ni ochadi), "qulflab qo'y = ekranni qulfla", taxalluslarim; pabji ni unut (o'chirish)"""
    }

    // ------------------------------------------------------------ TAXALLUSLAR (o'rgatish)
    private fun teach(raw: String): Reply? {
        var k: String? = null
        var v: String? = null
        val a = Regex("^(.+?)=(.+)$").find(raw.trim())
        if (a != null) {
            k = a.groupValues[1]
            v = a.groupValues[2]
        } else {
            val b = Regex("^o'rgat\\w*\\s+(.+?)\\s+degani\\s+(.+)$").find(Text.norm(raw))
            if (b != null) {
                k = b.groupValues[1]
                v = b.groupValues[2]
            }
        }
        if (k == null || v == null) return null
        val key = Text.norm(k).replace(Regex("^o'rgat\\w*\\s*"), "").trim()
        val value = Text.norm(v)
        if (key.isEmpty() || value.isEmpty()) return Reply("Qanday o'rgatay? Masalan: pabji = pubg", false)
        if (key == value) return Reply("Ikkalasi bir xil.", false)
        val m = Prefs.aliases(ctx)
        m[key] = value
        Prefs.saveAliases(ctx, m)
        return Reply("Yaxshi: «$key» deganda «$value» deb tushunaman.")
    }

    private fun applyAliases(t: String): String {
        val m = Prefs.aliases(ctx)
        if (m.isEmpty()) return t
        var r = t
        for (k in m.keys.sortedByDescending { it.length }) {
            r = r.replace(Regex("\\b" + Regex.escape(k) + "\\b"), Regex.escapeReplacement(m[k] ?: k))
        }
        return r
    }

    fun run(raw: String): Reply {
        teach(raw)?.let { return it }
        var t = Text.norm(raw)
        if (t.isEmpty()) return Reply("Eshitmadim.", false)

        if (Regex("\\btaxallus\\w*").containsMatchIn(t)) {
            val m = Prefs.aliases(ctx)
            if (m.isEmpty()) return Reply("Taxallus yo'q. O'rgatish: pabji = pubg")
            return Reply(m.entries.mapIndexed { i, e -> "${i + 1}) ${e.key} = ${e.value}" }.joinToString("\n"))
        }
        val forget = Regex("^(.+?)\\s+(?:ni\\s+)?unut\\w*$").find(t)
        if (forget != null) {
            val m = Prefs.aliases(ctx)
            val key = forget.groupValues[1].trim()
            if (m.remove(key) != null) {
                Prefs.saveAliases(ctx, m)
                return Reply("«$key» ni unutdim.")
            }
        }
        t = applyAliases(t)

        reminderCmd(t)?.let { return it }
        if (Regex("\\byordam\\b|nima\\s+qila\\s+olasan|buyruqlar").containsMatchIn(t)) return Reply(HELP)
        if (Regex("\\bqulf\\w*").containsMatchIn(t)) return global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Ekran qulflandi.")
        if (Regex("skr\\w*\\s*shot|screenshot|ekran\\s*rasm\\w*|ekranni\\s+rasmga").containsMatchIn(t)) return shot()
        if (Regex("\\b(chiroq|fonar|flesh|yoritgich)\\w*").containsMatchIn(t)) return torch(t)
        if (Regex("\\bkesh\\w*").containsMatchIn(t)) return cache(t)
        if (Regex("\\b(ortga|orqaga)\\b").containsMatchIn(t)) return global(AccessibilityService.GLOBAL_ACTION_BACK, "Ortga qaytdim.")
        if (Regex("ilovadan\\s+chiq|ilovani\\s+yop|\\bchiq\\b|bosh\\s+ekran|uyga\\s+qayt").containsMatchIn(t))
            return global(AccessibilityService.GLOBAL_ACTION_HOME, "Bosh ekranga chiqdim.")
        openApp(t)?.let { return it }
        return Reply("Tushunmadim. \"yordam\" deb ayting.", false)
    }

    // ------------------------------------------------------------ ESLATMALAR
    private fun reminderCmd(t: String): Reply? {
        val tn = Text.numberWords(t)

        if (Regex("\\b(barcha|hamma)\\w*\\s+eslatma\\w*|\\beslatmalar\\w*\\s+(o'chir|tozala)\\w*").containsMatchIn(tn) &&
            Regex("o'chir|tozala|bekor").containsMatchIn(tn)
        ) {
            val l = Store.all(ctx)
            for (x in l) Scheduler.cancel(ctx, x)
            for (x in l) Store.remove(ctx, x.id)
            return Reply("Hamma eslatmalar o'chirildi (${l.size} ta).")
        }

        val del = Regex("\\beslatma\\w*\\s+(\\d+)\\s*(?:ni\\s+)?(?:o'chir|bekor|tozala)\\w*").find(tn)
        if (del != null) {
            val n = del.groupValues[1].toInt()
            val l = Store.all(ctx)
            if (n < 1 || n > l.size) return Reply("$n-eslatma yo'q.", false)
            val x = l[n - 1]
            Scheduler.cancel(ctx, x)
            Store.remove(ctx, x.id)
            return Reply("O'chirdim: «${x.text}»")
        }

        if (Regex("\\beslatmalar\\w*|nima\\s+eslat\\w*|qaydlar\\w*").containsMatchIn(tn)) {
            val l = Store.all(ctx)
            if (l.isEmpty()) return Reply("Eslatma yo'q.")
            val now = System.currentTimeMillis()
            return Reply(l.mapIndexed { i, x ->
                var s = "${i + 1}) ${x.text}"
                if (x.time > 0) {
                    s += " - " + fmt.format(Date(x.time))
                    if (x.daily) s += " (har kuni)" else if (x.time < now) s += " (o'tdi)"
                }
                s
            }.joinToString("\n"))
        }

        val trig = Regex("\\beslat\\w*|\\beslab\\s+qol\\w*").containsMatchIn(tn)
        val w = Text.parseWhen(tn)
        if (w != null && (trig || Regex("\\bkeyin\\b|\\bdeb\\b").containsMatchIn(tn))) {
            val text = w.rest.ifEmpty { "Eslatma" }
            val item = Store.add(ctx, text, w.time, w.daily)
            val exact = Scheduler.schedule(ctx, item)
            var s = "Ayni " + fmt.format(Date(w.time)) + " da eslataman: «$text»"
            if (w.daily) s += " (har kuni)"
            if (!exact) s += "\nOgohlantirish: aniq signal ruxsati yo'q, vaqt biroz og'ishi mumkin."
            return Reply(s)
        }
        if (trig) {
            val text = Text.cleanRest(tn)
            if (text.isEmpty()) return Reply("Nimani eslab qolay?", false)
            Store.add(ctx, text, 0, false)
            return Reply("Eslab qoldim: «$text»")
        }
        return null
    }

    // ------------------------------------------------------------ GLOBAL AMALLAR
    private fun needAcc(): Reply {
        try {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
        return Reply("Avval «Maxsus imkoniyatlar»da Yordamchi xizmatini yoqing. Sozlamalarni ochdim.", false)
    }

    private fun global(code: Int, msg: String): Reply {
        val s = ActionService.instance ?: return needAcc()
        return if (s.performGlobalAction(code)) Reply(msg) else Reply("Bajarib bo'lmadi.", false)
    }

    private fun shot(): Reply {
        val s = ActionService.instance ?: return needAcc()
        AssistantService.instance?.hideForShot()
        Handler(Looper.getMainLooper()).postDelayed({
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        }, 500)
        return Reply("Skrinshot olinmoqda.")
    }

    // ------------------------------------------------------------ CHIROQ
    private fun torch(t: String): Reply {
        val off = Regex("o'chir|so'ndir|o'chiq|yopib").containsMatchIn(t)
        val on = Regex("\\byoq\\w*|\\bochib\\b|\\boch\\b|yondir|yorit").containsMatchIn(t)
        val want = when {
            off && !on -> false
            on -> true
            else -> !torchOn
        }
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return Reply("Chiroq (flesh) topilmadi.", false)
            cm.setTorchMode(id, want)
            torchOn = want
            Reply(if (want) "Chiroq yondi." else "Chiroq o'chdi.")
        } catch (e: Exception) {
            Reply("Chiroqni boshqara olmadim: ${e.message}", false)
        }
    }

    // ------------------------------------------------------------ KESH
    private fun cache(t: String): Reply {
        val q = Regex("\\b(kesh\\w*|tozala\\w*|o'chir\\w*|ilova\\w*|dastur\\w*|ni|ning|va|iltimos)\\b")
            .replace(t, " ").replace(Regex("\\s+"), " ").trim()
        if (q.isNotEmpty()) {
            val app = findApp(q)
            if (app != null) {
                return try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    Reply("${app.label}: «Xotira» - «Keshni tozalash» tugmasini bosing. (Android boshqa ilova keshini o'zim tozalashga ruxsat bermaydi.)")
                } catch (e: Exception) {
                    Reply("Sozlamalarni ochib bo'lmadi.", false)
                }
            }
        }
        try {
            ctx.cacheDir.deleteRecursively()
            ctx.externalCacheDir?.deleteRecursively()
        } catch (_: Exception) {
        }
        try {
            ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
        return Reply("O'zimning keshimni tozaladim. Boshqa ilovalar keshi uchun Xotira sozlamalarini ochdim.")
    }

    // ------------------------------------------------------------ ILOVA OCHISH
    @Suppress("DEPRECATION")
    private fun apps(): List<AppInfo> {
        val now = System.currentTimeMillis()
        if (appCache.isNotEmpty() && now - appCacheAt < 60000) return appCache
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(i, PackageManager.ResolveInfoFlags.of(0))
        else pm.queryIntentActivities(i, 0)
        appCache = list.map {
            val label = it.loadLabel(pm).toString()
            AppInfo(label, Text.norm(label), it.activityInfo.packageName)
        }.filter { it.pkg != ctx.packageName }
        appCacheAt = now
        return appCache
    }

    fun findApp(q0: String): AppInfo? {
        val q = Text.norm(q0).removePrefix("ilovani ").removePrefix("ilova ").trim()
        if (q.isEmpty()) return null
        val cands = ArrayList<String>()
        cands.add(q)
        ALIAS[q]?.let { cands.addAll(it) }
        var best: AppInfo? = null
        var bestScore = Int.MAX_VALUE
        for (a in apps()) {
            for (c in cands) {
                val sc = when {
                    a.norm == c -> 0
                    a.norm.startsWith(c) || c.startsWith(a.norm) -> 1
                    a.norm.contains(c) -> 2
                    else -> {
                        val d = Text.lev(a.norm, c)
                        if (d <= maxOf(1, c.length / 4)) 3 + d else Int.MAX_VALUE
                    }
                }
                if (sc < bestScore) {
                    bestScore = sc
                    best = a
                }
            }
        }
        return best
    }

    private fun openApp(t: String): Reply? {
        val m = Regex("^(?:iltimos\\s+)?(.+?)\\s+(?:och|ochib\\s+ber|ochgin|oching|ochsang|ishga\\s+tushir\\w*)$").find(t)
            ?: return null
        val q = m.groupValues[1].trim()
        var app: AppInfo? = null
        for (c in listOf(q, q.removeSuffix(" ni"), q.removeSuffix("ni"), q.removeSuffix("ga"))) {
            app = findApp(c)
            if (app != null) break
        }
        if (app == null) return Reply("«$q» nomli ilova topilmadi.", false)
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                ?: return Reply("${app.label} ochilmadi.", false)
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Reply("${app.label} ochildi.")
        } catch (e: Exception) {
            Reply("${app.label} ochilmadi: ${e.message}", false)
        }
    }
}

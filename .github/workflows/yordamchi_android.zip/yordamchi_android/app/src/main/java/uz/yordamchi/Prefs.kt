package uz.yordamchi

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

object Prefs {
    val EMOJIS = listOf("😶", "😏", "🫡", "😛", "😐", "🤠", "💀", "😎", "🤓", "🥸")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("yordamchi", Context.MODE_PRIVATE)

    fun emoji(c: Context): String = sp(c).getString("emoji", EMOJIS[0]) ?: EMOJIS[0]
    fun setEmoji(c: Context, e: String) = sp(c).edit().putString("emoji", e).apply()

    fun wake(c: Context): Boolean = sp(c).getBoolean("wake", false)
    fun setWake(c: Context, v: Boolean) = sp(c).edit().putBoolean("wake", v).apply()

    fun y(c: Context, def: Int): Int = sp(c).getInt("y", def)
    fun setY(c: Context, v: Int) = sp(c).edit().putInt("y", v).apply()

    fun nextId(c: Context): Int {
        val s = sp(c)
        val n = s.getInt("nid", 1)
        s.edit().putInt("nid", n + 1).apply()
        return n
    }

    /** Foydalanuvchi o'rgatgan taxalluslar: "pabji" -> "pubg". */
    fun aliases(c: Context): MutableMap<String, String> {
        val m = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(sp(c).getString("alias", "{}") ?: "{}")
            for (k in o.keys()) m[k] = o.getString(k)
        } catch (_: Exception) {
        }
        return m
    }

    fun saveAliases(c: Context, m: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        sp(c).edit().putString("alias", o.toString()).apply()
    }
}

package uz.yordamchi

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Faqat global amallar uchun: qulflash, ortga, bosh ekran, skrinshot. Ekrandagi matnni o'qimaydi. */
class ActionService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: ActionService? = null
    }

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

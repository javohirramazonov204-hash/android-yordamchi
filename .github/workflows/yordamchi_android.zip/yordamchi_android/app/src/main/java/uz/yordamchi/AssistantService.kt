package uz.yordamchi

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Ekran chetida yarim yashirin emoji, bosilganda chiqib keladi va ovozni tinglaydi.
 * Buyruq bajarilgach yana chetga yashirinadi.
 */
class AssistantService : Service(), Voice.Callback {
    companion object {
        @Volatile
        var instance: AssistantService? = null
        const val CH_FG = "fg"
        const val ACTION_STOP = "uz.yordamchi.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AssistantService::class.java))
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var emoji: TextView? = null
    private var bubble: TextView? = null
    private var ep: WindowManager.LayoutParams? = null
    private var bp: WindowManager.LayoutParams? = null
    private var voice: Voice? = null
    private var awaitUntil = 0L
    private var pulse: ObjectAnimator? = null
    private var shown = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "emoji" -> {
                emoji?.text = Prefs.emoji(this@AssistantService)
            }
            "wake" -> {
                voice?.broken = false
                applyWake()
            }
        }
    }

    private val hideBubble = Runnable {
        bubble?.let { if (it.parent != null) wm.removeView(it) }
        if (voice?.mode != Voice.Mode.ONCE) slide(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (emoji == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            instance = this
            buildOverlay()
            voice = Voice(this, this)
            Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
            applyWake()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        instance = null
        h.removeCallbacksAndMessages(null)
        try {
            Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Exception) {
        }
        voice?.release()
        pulse?.cancel()
        try {
            emoji?.let { if (it.parent != null) wm.removeView(it) }
            bubble?.let { if (it.parent != null) wm.removeView(it) }
        } catch (_: Exception) {
        }
        emoji = null
        bubble = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ FOREGROUND
    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_FG, "Yordamchi ishlayapti", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_FG)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Yordamchi ishlayapti")
            .setContentText("Emojini bosing va gapiring")
            .setContentIntent(open)
            .addAction(0, "To'xtatish", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            try {
                ServiceCompat.startForeground(this, 1, n, type)
            } catch (e: Exception) {
                try {
                    ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                } catch (e2: Exception) {
                    stopSelf()
                }
            }
        } else {
            startForeground(1, n)
        }
    }

    // ------------------------------------------------------------ OVERLAY
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun size() = dp(56)
    private fun hiddenX() = screenW() - (size() * 0.4f).toInt()
    private fun shownX() = screenW() - size() - dp(6)

    private fun buildOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val sz = size()

        val tv = TextView(this)
        tv.text = Prefs.emoji(this)
        tv.textSize = 30f
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xF0FFFFFF.toInt())
        bg.setStroke(dp(2), 0x40000000)
        tv.background = bg

        val lp = WindowManager.LayoutParams(
            sz, sz,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = hiddenX()
        lp.y = Prefs.y(this, screenH() / 3)

        tv.setOnTouchListener(object : View.OnTouchListener {
            var downY = 0f
            var startY = 0
            var moved = false
            var downT = 0L
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downY = e.rawY
                        startY = lp.y
                        moved = false
                        downT = System.currentTimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = e.rawY - downY
                        if (abs(dy) > dp(8) || moved) {
                            moved = true
                            lp.y = (startY + dy).toInt().coerceIn(dp(24), screenH() - sz - dp(24))
                            try {
                                wm.updateViewLayout(v, lp)
                            } catch (_: Exception) {
                            }
                            bp?.let { b ->
                                b.y = lp.y
                                bubble?.let { bv -> if (bv.parent != null) wm.updateViewLayout(bv, b) }
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) Prefs.setY(this@AssistantService, lp.y)
                        else if (System.currentTimeMillis() - downT > 600) openMain()
                        else onTap()
                        return true
                    }
                }
                return false
            }
        })

        ep = lp
        emoji = tv
        wm.addView(tv, lp)

        val b = TextView(this)
        b.textSize = 14f
        b.setTextColor(0xFFFFFFFF.toInt())
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        b.maxWidth = (screenW() * 0.7f).toInt()
        val bbg = GradientDrawable()
        bbg.cornerRadius = dp(16).toFloat()
        bbg.setColor(0xEE263238.toInt())
        b.background = bbg
        bubble = b

        pulse = ObjectAnimator.ofFloat(tv, "alpha", 0.55f, 1f).apply {
            duration = 1500
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    private fun slide(show: Boolean) {
        val lp = ep ?: return
        val v = emoji ?: return
        shown = show
        if (show) {
            pulse?.cancel()
            v.alpha = 1f
        } else if (pulse?.isRunning == false) {
            pulse?.start()
        }
        val target = if (show) shownX() else hiddenX()
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try {
                    wm.updateViewLayout(v, lp)
                } catch (_: Exception) {
                }
            }
            start()
        }
    }

    private fun showBubble(text: String, ms: Long) {
        val b = bubble ?: return
        var lp = bp
        if (lp == null) {
            lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.END
            bp = lp
        }
        b.text = text
        lp.x = size() + dp(14)
        lp.y = ep?.y ?: 0
        try {
            if (b.parent == null) wm.addView(b, lp) else wm.updateViewLayout(b, lp)
        } catch (_: Exception) {
        }
        h.removeCallbacks(hideBubble)
        if (ms > 0) h.postDelayed(hideBubble, ms)
    }

    private fun openMain() {
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    /** Skrinshotda emoji ko'rinmasligi uchun vaqtincha yashiradi. */
    fun hideForShot() {
        emoji?.visibility = View.INVISIBLE
        bubble?.visibility = View.INVISIBLE
        h.postDelayed({
            emoji?.visibility = View.VISIBLE
            bubble?.visibility = View.VISIBLE
        }, 2500)
    }

    /** Eslatma kabi tashqi xabarlar uchun. */
    fun say(text: String) {
        slide(true)
        showBubble(text, 12000)
    }

    // ------------------------------------------------------------ OVOZ
    private fun onTap() {
        val v = voice ?: return
        if (v.mode == Voice.Mode.ONCE) {
            v.stop()
            showBubble("Bekor qilindi", 1500)
            applyWake()
            return
        }
        slide(true)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showBubble("Mikrofon ruxsati yo'q. Ilovani ochib ruxsat bering.", 5000)
            return
        }
        showBubble("🎙 Eshitaman...", 0)
        v.start(Voice.Mode.ONCE)
    }

    private fun applyWake() {
        val v = voice ?: return
        if (Prefs.wake(this)) {
            if (v.broken) return
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            if (v.mode == Voice.Mode.NONE) v.start(Voice.Mode.WAKE)
        } else if (v.mode == Voice.Mode.WAKE) {
            v.stop()
        }
    }

    override fun onHeard(text: String, mode: Voice.Mode) {
        var cmd = text
        if (mode == Voice.Mode.WAKE) {
            val now = System.currentTimeMillis()
            val s = Wake.strip(text)
            if (s == null) {
                if (now < awaitUntil) {
                    awaitUntil = 0
                } else {
                    return
                }
            } else if (s.isBlank()) {
                awaitUntil = now + 7000
                slide(true)
                showBubble("🎙 Eshitaman...", 7000)
                return
            } else {
                cmd = s
            }
        } else {
            val s = Wake.strip(text)
            if (!s.isNullOrBlank()) cmd = s
        }
        val r = Commands(this).run(cmd)
        slide(true)
        showBubble("🗣 $text\n${r.text}", 6000L + minOf(r.text.length * 30L, 6000L))
        applyWake()
    }

    override fun onVoiceState(msg: String) {
        slide(true)
        showBubble(msg, 0)
    }

    override fun onVoiceError(msg: String) {
        slide(true)
        showBubble(msg, 4500)
        h.postDelayed({ applyWake() }, 3000)
    }
}

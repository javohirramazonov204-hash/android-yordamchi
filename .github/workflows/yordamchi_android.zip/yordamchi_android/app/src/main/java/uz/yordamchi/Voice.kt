package uz.yordamchi

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** "Hoy Yordamchi ..." chaqiruv so'zini ajratish (MaoMao'dagi kabi, noaniq eshitilganini ham qabul qiladi). */
object Wake {
    private val names = listOf("yordamchi", "hamroh", "madadkor")
    private val hoy = setOf("hoy", "hey", "hay", "xoy", "oy")

    private fun isName(tok: String): Boolean {
        if (tok.length < 5) return false
        for (n in names) {
            if (tok == n) return true
            if (tok.length >= 6 && tok.startsWith(n.take(6))) return true
            val sim = 1.0 - Text.lev(tok, n).toDouble() / maxOf(tok.length, n.length)
            if (sim >= 0.72) return true
        }
        return false
    }

    /** Chaqiruv so'zi bo'lsa qolgan buyruqni (bo'sh bo'lishi mumkin), bo'lmasa null qaytaradi. */
    fun strip(text: String): String? {
        val w = Text.norm(text).split(" ").filter { it.isNotEmpty() }
        if (w.isEmpty()) return null
        var i = 0
        if (w[0] in hoy) i = 1
        if (i >= w.size) return null
        if (!isName(w[i])) return null
        return w.drop(i + 1).joinToString(" ")
    }
}

class Voice(private val ctx: Context, private val cb: Callback) : RecognitionListener {
    enum class Mode { NONE, ONCE, WAKE }

    interface Callback {
        fun onHeard(text: String, mode: Mode)
        fun onVoiceState(msg: String)
        fun onVoiceError(msg: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var loading = false
    private var lastErr = ""
    private val waiters = ArrayList<(Boolean) -> Unit>()
    private var service: SpeechService? = null
    private var sr: SpeechRecognizer? = null
    private var delivered = false

    @Volatile
    var mode: Mode = Mode.NONE
        private set

    /** Doim tinglash model yoki mikrofon xatosi tufayli ishlamasa true (qayta urinmaydi). */
    @Volatile
    var broken = false

    fun start(m: Mode) {
        stopInternal()
        mode = m
        if (model == null) {
            if (m == Mode.ONCE) cb.onVoiceState("Ovoz modeli yuklanyapti...")
            loadModel { ok ->
                if (mode == m) {
                    if (ok) begin() else fail(m)
                }
            }
            return
        }
        begin()
    }

    fun stop() {
        stopInternal()
        mode = Mode.NONE
    }

    fun release() {
        stop()
        try {
            model?.close()
        } catch (_: Throwable) {
        }
        model = null
    }

    // ------------------------------------------------------------ VOSK
    private fun begin() {
        try {
            val rec = Recognizer(model, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            service = s
            delivered = false
            val ok = if (mode == Mode.ONCE) {
                cb.onVoiceState("🎙 Eshitaman...")
                s.startListening(this, 10000)
            } else {
                s.startListening(this)
            }
            if (!ok) {
                if (mode == Mode.WAKE) broken = true
                mode = Mode.NONE
                stopInternal()
                cb.onVoiceError("Mikrofon band yoki ishga tushmadi.")
            }
        } catch (e: Throwable) {
            if (mode == Mode.WAKE) broken = true
            mode = Mode.NONE
            cb.onVoiceError("Mikrofonni ochib bo'lmadi: ${e.message}")
        }
    }

    private fun fail(m: Mode) {
        if (m == Mode.ONCE) {
            fallbackOnce(lastErr)
        } else {
            mode = Mode.NONE
            broken = true
            cb.onVoiceError("Doim tinglash uchun Vosk modeli kerak: $lastErr")
        }
    }

    private fun stopInternal() {
        try {
            service?.stop()
            service?.shutdown()
        } catch (_: Throwable) {
        }
        service = null
        try {
            sr?.destroy()
        } catch (_: Throwable) {
        }
        sr = null
    }

    private fun json(h: String?, key: String): String {
        return try {
            JSONObject(h ?: "{}").optString(key, "").trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun deliver(text: String) {
        if (text.isBlank() || mode == Mode.NONE) return
        if (mode == Mode.ONCE) {
            if (delivered) return
            delivered = true
            stopInternal()
            mode = Mode.NONE
            cb.onHeard(text, Mode.ONCE)
        } else {
            cb.onHeard(text, Mode.WAKE)
        }
    }

    override fun onPartialResult(hypothesis: String?) {
        if (mode == Mode.ONCE) {
            val p = json(hypothesis, "partial")
            if (p.isNotBlank()) cb.onVoiceState("🎙 $p")
        }
    }

    override fun onResult(hypothesis: String?) = deliver(json(hypothesis, "text"))

    override fun onFinalResult(hypothesis: String?) = deliver(json(hypothesis, "text"))

    override fun onError(exception: Exception?) {
        mode = Mode.NONE
        stopInternal()
        cb.onVoiceError("Ovoz xatosi: ${exception?.message}")
    }

    override fun onTimeout() {
        if (mode == Mode.ONCE && !delivered) {
            stopInternal()
            mode = Mode.NONE
            cb.onVoiceError("Eshitmadim.")
        }
    }

    // ------------------------------------------------------------ MODEL
    private fun loadModel(done: (Boolean) -> Unit) {
        waiters.add(done)
        if (loading) return
        loading = true
        Thread {
            var ok = false
            try {
                val dir = ensureModelDir()
                model = Model(dir.absolutePath)
                ok = true
            } catch (e: Throwable) {
                lastErr = e.message ?: e.toString()
            }
            main.post {
                loading = false
                val l = ArrayList(waiters)
                waiters.clear()
                for (w in l) w(ok)
            }
        }.start()
    }

    private fun isModel(d: File) = File(d, "am").isDirectory && File(d, "graph").isDirectory

    private fun ensureModelDir(): File {
        val dest = File(ctx.filesDir, "model-uz")
        if (isModel(dest)) return dest
        val names = ctx.assets.list("model-uz")
        if (names == null || names.isEmpty()) throw IOException("assets/model-uz papkasi topilmadi")
        dest.deleteRecursively()
        val tmp = File(ctx.filesDir, "model-uz.tmp")
        tmp.deleteRecursively()
        copyAssets("model-uz", tmp)
        val root = if (isModel(tmp)) tmp else tmp.listFiles()?.firstOrNull { it.isDirectory && isModel(it) }
            ?: throw IOException("Model papkasi noto'g'ri: ichida am va graph bo'lishi kerak")
        if (!root.renameTo(dest)) throw IOException("Modelni ko'chirib bo'lmadi")
        tmp.deleteRecursively()
        return dest
    }

    private fun copyAssets(path: String, dest: File) {
        val names = ctx.assets.list(path) ?: return
        if (names.isEmpty()) {
            try {
                dest.parentFile?.mkdirs()
                ctx.assets.open(path).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
            } catch (_: IOException) {
            }
        } else {
            dest.mkdirs()
            for (n in names) copyAssets("$path/$n", File(dest, n))
        }
    }

    // ------------------------------------------------------------ ZAXIRA: tizim tanigichi (Google)
    private fun fallbackOnce(reason: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            mode = Mode.NONE
            cb.onVoiceError("Ovoz modeli yo'q ($reason), tizim tanigichi ham topilmadi.")
            return
        }
        cb.onVoiceState("🎙 Eshitaman (Google)...")
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                mode = Mode.NONE
                stopInternal()
                cb.onVoiceError("Eshitmadim (xato $error).")
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                mode = Mode.NONE
                stopInternal()
                if (!t.isNullOrBlank()) cb.onHeard(t, Mode.ONCE) else cb.onVoiceError("Eshitmadim.")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) cb.onVoiceState("🎙 $t")
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }
}

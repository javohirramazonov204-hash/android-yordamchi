package uz.yordamchi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.app.AlarmManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    companion object {
        var stoppedByUser = false
    }

    private lateinit var permBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var outTv: TextView
    private lateinit var svcBtn: Button
    private val emojiViews = ArrayList<TextView>()
    private val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refresh()
        maybeStart()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun label(t: String, sp: Float = 14f, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun button(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        scroll.addView(root)
        setContentView(scroll)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(dp(16) + s.left, dp(16) + s.top, dp(16) + s.right, dp(16) + s.bottom)
            insets
        }

        root.addView(label("Yordamchi", 26f, true))
        root.addView(label("Ekran chetida emoji turadi. Bosing va gapiring: \"ekranni qulfla\", \"chiroqni yoq\", \"telegram och\"..."))

        // --- Ruxsatlar
        root.addView(label("Ruxsatlar", 18f, true))
        permBox = LinearLayout(this)
        permBox.orientation = LinearLayout.VERTICAL
        root.addView(permBox)

        // --- Boshqaruv
        svcBtn = button("") {
            if (AssistantService.instance != null) {
                stoppedByUser = true
                AssistantService.stop(this)
            } else {
                stoppedByUser = false
                maybeStart()
            }
            window.decorView.postDelayed({ refresh() }, 400)
        }
        root.addView(svcBtn)

        val sw = Switch(this)
        sw.text = "Doim tinglash: \"Hoy Yordamchi, ...\" desangiz ishlaydi (batareyani ko'proq yeydi)"
        sw.isChecked = Prefs.wake(this)
        sw.setOnCheckedChangeListener { _, c -> Prefs.setWake(this, c) }
        sw.setPadding(0, dp(12), 0, dp(12))
        root.addView(sw)

        // --- Emoji tanlash
        root.addView(label("Ko'rinish", 18f, true))
        val grid = GridLayout(this)
        grid.columnCount = 5
        for (e in Prefs.EMOJIS) {
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 30f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(10), dp(10), dp(10), dp(10))
            tv.setOnClickListener {
                Prefs.setEmoji(this, e)
                highlight()
            }
            emojiViews.add(tv)
            grid.addView(tv)
        }
        root.addView(grid)
        highlight()

        // --- Buyruq sinovi
        root.addView(label("Buyruqni yozib sinash", 18f, true))
        val et = EditText(this)
        et.hint = "masalan: 15:30 da dori ich deb eslat"
        et.setSingleLine(true)
        root.addView(et)
        outTv = label("")
        root.addView(button("Bajar") {
            val r = Commands(this).run(et.text.toString())
            outTv.text = r.text
            et.setText("")
            refreshList()
        })
        root.addView(outTv)

        // --- Eslatmalar
        root.addView(label("Eslatmalar va qaydlar", 18f, true))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        root.addView(listBox)

        // --- Yordam
        root.addView(label("Buyruqlar", 18f, true))
        root.addView(label(Commands.HELP))

        val need = ArrayList<String>()
        if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else maybeStart()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        maybeStart()
    }

    private fun maybeStart() {
        if (!stoppedByUser && Settings.canDrawOverlays(this) && AssistantService.instance == null) {
            try {
                AssistantService.start(this)
            } catch (_: Exception) {
            }
            window.decorView.postDelayed({ refresh() }, 600)
        }
    }

    private fun highlight() {
        val cur = Prefs.emoji(this)
        for (tv in emojiViews) {
            if (tv.text.toString() == cur) {
                val g = GradientDrawable()
                g.cornerRadius = dp(12).toFloat()
                g.setStroke(dp(3), 0xFF3D5AFE.toInt())
                tv.background = g
            } else {
                tv.background = null
            }
        }
    }

    private fun permRow(title: String, ok: Boolean, action: (() -> Unit)?) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val t = label((if (ok) "✅ " else "⬜ ") + title)
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (!ok && action != null) row.addView(button("Yoqish") { action() })
        permBox.addView(row)
    }

    private fun accOn(): Boolean {
        if (ActionService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }

    private fun refresh() {
        permBox.removeAllViews()
        permRow("Boshqa ilovalar ustida ko'rsatish (emoji uchun)", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow("Maxsus imkoniyatlar (qulflash, ortga, skrinshot, bosh ekran)", accOn()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        if (!accOn()) {
            permBox.addView(label("Yoqib bo'lmasa: «Ilova haqida» sahifasida ⋮ - «Cheklangan sozlamalarga ruxsat berish», keyin qayta urining.", 12f))
            permBox.addView(button("Ilova sahifasini ochish") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            })
        }
        permRow("Mikrofon (ovoz uchun)", has(Manifest.permission.RECORD_AUDIO)) {
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            permRow("Bildirishnomalar (eslatma uchun)", has(Manifest.permission.POST_NOTIFICATIONS)) {
                permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            permRow("Aniq vaqtli signal (eslatma aniq vaqtda chalinishi uchun)", am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        permRow("Batareya cheklovisiz ishlash (tavsiya)", pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        svcBtn.text = if (AssistantService.instance != null) "Yordamchini to'xtatish" else "Yordamchini ishga tushirish"
        refreshList()
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val l = Store.all(this)
        if (l.isEmpty()) {
            listBox.addView(label("Hozircha yo'q."))
            return
        }
        val now = System.currentTimeMillis()
        l.forEachIndexed { i, x ->
            var s = "${i + 1}) ${x.text}"
            if (x.time > 0) {
                s += "\n    " + fmt.format(Date(x.time))
                if (x.daily) s += " (har kuni)" else if (x.time < now) s += " (o'tdi)"
            }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label(s), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("✕") {
                Scheduler.cancel(this, x)
                Store.remove(this, x.id)
                refreshList()
            })
            listBox.addView(row)
        }
    }
}
